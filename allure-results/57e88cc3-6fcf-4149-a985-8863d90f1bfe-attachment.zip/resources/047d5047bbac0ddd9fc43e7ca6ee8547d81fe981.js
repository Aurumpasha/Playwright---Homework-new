;(function($) {
    com.kms.web.layout.actionbar.extend(function(self) {
        var button = {
            SaveAndRelocate : {
                cmTree : com.kms.web.component.cmTree,
                allowedSubTypes : {},
                default_folder_subtypes : ["LINKS_FOLDER", "IMAGES", "LIST", "FOLDERTAB", "SPREAD", "TOPICS", "3G_HANDSET"],
                disabledOn : ['FOLDER_HOMEPAGE', 'WIZARD', 'FEEDBACK'],

                active : function() {
                    switch(true) {
                        case self.itemScope.context.item_id == null :
                        case self.itemScope.context.isInfo !== 'yes' :
                        case self.itemScope.context.isView :
                        case self.itemScope.context.lockingStatus === 'otherCmLock' :
                        case self.isItemReadOnly() :
                        case !self.options.canMove :
                            return false;
                        default : return true;
                    }
                },

                click : function(canBeSavedAsFloating, complete, isSaveAndPreview) {
                    var dialogId = 'relocate-dialog';

                    var $dialog = $('#' + dialogId);

                    var itemType = self.itemScope.context.item_type;
                    var folderType = 'FOLDER';

                    if (!$dialog.length) {
                        $dialog = $('<div>').attr('id', dialogId).appendTo('body');
                    }

                    complete = complete || function(isContinue) {
                        if (!isContinue) return;

                        var options = {
                            ignoreFloatingCheck : true,
                        };

                        if (isSaveAndPreview) {
                            options = Object.assign({ saveAndPreview: true }, options);
                        }

                        self.buttons.Save.click(options);
                    };

                    if (itemType === folderType && self.itemScope.utils.item.isRootFolder()) {
                        self.buttons.Save.click({
                            ignoreFloatingCheck: true
                        });

                        complete(true);
                        return;
                    }

                    var dialogButtons = [{
                        id : 'relocate-save',
                        text : button.SaveAndRelocate.dictionary.save,
                        disabled : !self.options.canMove,
                        click : function () {
                            var activeNode = $(this).data('tree').dynatree('getActiveNode');
                            var that = $(this);

                            if (activeNode && activeNode.data.id) {
                                com.kms.web.component.cmTree.actions.onCheckPermissions(activeNode, function() {
                                    self.itemScope.utils.item.update.setRequestParam('destinationId', activeNode.data.id);
                                    complete(true);
                                    that.dialog('close');
                                });
                            }
                        }
                    }];

                    if (!!canBeSavedAsFloating) {
                        dialogButtons.unshift({
                            id : 'floating-save',
                            text : button.SaveAndRelocate.dictionary.saveAsFloating,
                            disabled : true,
                            click : function () {
                                complete(true);
                                $(this).dialog('close');
                            }
                        });
                    }
                    else {
                        self.itemScope.utils.setDisplayMode('UPDATE');
                    }

                    $dialog.dialog({
                        title : button.SaveAndRelocate.dictionary.selectFolder,
                        autoOpen : false,
                        width : 500,
                        height : 500,
                        resizable : false,
                        modal : true,
                        open : function() {
                            $dialog.kmsLoadingArea('show');

                            button.SaveAndRelocate.cmTree.dtdsMapPromise.done(function() {
                                // set dtd allowed subtypes
                                button.SaveAndRelocate.allowedSubTypes = {};

                                $.each(button.SaveAndRelocate.cmTree.dtdsMap, function(subType, allowedSubTypes) {
                                    if (!!~$.inArray(subType, button.SaveAndRelocate.default_folder_subtypes)) {
                                        // extend allowed subtypes for all types of folders
                                        $.each(button.SaveAndRelocate.default_folder_subtypes, function (index, sub_type) {
                                            allowedSubTypes.push({ sub_type : sub_type });
                                        });
                                    }

                                    button.SaveAndRelocate.allowedSubTypes[subType] = $.map(allowedSubTypes, function(data) {
                                        return data.sub_type;
                                    });
                                });

                                if (button.SaveAndRelocate.allowedSubTypes.FOLDERTAB) {
                                    // Clone allowed subtypes of FOLDERTAB to other types of folders
                                    $.each(button.SaveAndRelocate.default_folder_subtypes, function (index, subType) {
                                        if (!button.SaveAndRelocate.allowedSubTypes[subType]) {
                                            button.SaveAndRelocate.allowedSubTypes[subType] = button.SaveAndRelocate.allowedSubTypes.FOLDERTAB;
                                        }
                                    });
                                }

                                // get current parent
                                var itemParent = self.itemScope.utils.item.getParent();

                                // initialize tree
                                var $tree = $('<div>').attr('id', 'relocate-tree').appendTo($dialog).dynatree({
                                    autoCollapse : true,
                                    selectMode : 1,
                                    autoFocus: false,
                                    imagePath : self.options.imgLocation.concat('/activeicons/'),
                                    strings: {
                                        loading  : button.SaveAndRelocate.cmTree.dictionary.loading,
                                        loadError: button.SaveAndRelocate.cmTree.dictionary.loadError
                                    },
                                    initAjax : {
                                        url : self.options.controllerLocation.concat('/tree/content-management/branch/nodes'),
                                        data : {
                                            parentId : button.SaveAndRelocate.cmTree.options.rootItemId
                                        }
                                    },

                                    onPostInit : function() {
                                        $dialog.kmsLoadingArea('hide');
                                    },

                                    onCreate  : function (node) {
                                        if(!node.data.hasOwnProperty('id')) {
                                            return;
                                        }

                                        var itemSubType = self.itemScope.contextGet('item_sub_type');
                                        var allowedSubTypes = button.SaveAndRelocate.allowedSubTypes[node.data.sub_type];
                                        var restricted = !button.SaveAndRelocate.cmTree.dtdsMapReady
                                            || allowedSubTypes.indexOf(itemSubType) === -1
                                            || button.SaveAndRelocate.disabledOn.indexOf(itemSubType) !== -1
                                            || !node.data.updateAllowed;

                                        var isParentNode = itemParent ? itemParent.id === node.data.id : false;

                                        $.extend(node.data, {
                                            isFolder : true,
                                            isLazy : !!parseInt(node.data.sons, 10),
                                            restricted : restricted,
                                            isParentNode : isParentNode,
                                            icon : false
                                        });

                                        node.render();
                                    },

                                    onRender: function (node, element) {
                                        // draw icon
                                        var $itemIcon = $.kmsHelperItemFontIcon(node.data.sub_type, null, true);
                                        var $node = $(node.span);

                                        if (node.data.restricted) {
                                            $itemIcon.addClass('kms-icon--SaveAndLock');
                                        }

                                        if (node.data.isParentNode) {
                                            $itemIcon.addClass('kms-icon--check');
                                        }

                                        // remove last icon - if exists
                                        $node.find('.kms-icon').remove();

                                        // insert new icon
                                        $itemIcon.insertAfter($node.find('.dynatree-expander, .dynatree-connector'));
                                    },

                                    onLazyRead : function (node) {
                                        node.appendAjax($.extend(true, {}, this.options.initAjax, {
                                            data : {
                                                parentId : node.data.id
                                            }
                                        }));
                                    },

                                    onActivate : function(node) {
                                        if (!node.data.restricted) {
                                            $dialog.dialog('widget').find('button#relocate-save').button('enable');
                                        }
                                    },

                                    onDeactivate : function() {
                                        $dialog.dialog('widget').find('button#relocate-save').button('disable');
                                    }
                                });

                                // store tree instance
                                $dialog.data('tree', $tree);

                                var $dialogWidget = $dialog.dialog('widget');

                                if (!!canBeSavedAsFloating) {
                                    $dialogWidget
                                        .find('button#floating-save')
                                        .button('enable');
                                }

                                $dialogWidget.focus();
                            });
                        },

                        close : function() {
                            complete(false);
                            $(this).empty();
                        },

                        buttons : dialogButtons
                    });

                    $dialog.dialog('open');
                }
            }
        };

        return button;
    });
})(jQuery);
