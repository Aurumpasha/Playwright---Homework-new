function getJson(json) {
    try {
        return JSON.parse(json);
    } catch (e) {
        return null;
    }
}

// TinyMCE
function clearFileInput() {
    var fileInput = $('.tox-dropzone input');
    fileInput.attr('value', '');
}

var NODE_NAMES = {
    span: 'SPAN',
    li: 'LI',
    ul: 'UL',
    ol: 'OL',
};

var fetchController = undefined;

var PRESET_REGEX = 'table-preset-';

const BASE_COLORS = [
    '#BFEDD2', 'Light Green',
    '#FBEEB8', 'Light Yellow',
    '#F8CAC6', 'Light Red',
    '#ECCAFA', 'Light Purple',
    '#C2E0F4', 'Light Blue',
    '#2DC26B', 'Green',
    '#F1C40F', 'Yellow',
    '#E03E2D', 'Red',
    '#B96AD9', 'Purple',
    '#3598DB', 'Blue',
    '#169179', 'Dark Turquoise',
    '#E67E23', 'Orange',
    '#BA372A', 'Dark Red',
    '#843FA1', 'Dark Purple',
    '#236FA1', 'Dark Blue',
    '#ECF0F1', 'Light Gray',
    '#CED4D9', 'Medium Gray',
    '#95A5A6', 'Gray',
    '#7E8C8D', 'Dark Gray',
    '#34495E', 'Navy Blue',
    '#000000', 'Black',
];

function getLi(node) {
    if (node === null) return;

    if (node.nodeName === NODE_NAMES.li) return node;

    return getLi(node.parentNode);
}

// Add possibility to cancel ajax requests
function createJqueryAjaxAbortAdapter(signal) {
    return function(jqXhr) {
        signal.addEventListener('abort', function() {
            jqXhr.abort();
        });
    };
}

async function processFileEntry(file, itemContext, controllerLocation, editorInstance) {
    if (itemContext.itemId && itemContext.itemVersion && itemContext.itemRevision) {
        const formData = createFormData(file, itemContext);
        await uploadImage(file, formData, controllerLocation, editorInstance);
    }
}

function createFormData(file, itemContext) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('itemId', itemContext.itemId);
    formData.append('itemVersion', itemContext.itemVersion);
    formData.append('itemRevision', itemContext.itemRevision);
    return formData;
}

async function uploadImage(file, formData, controllerLocation, editorInstance) {
    try {
        const img = await loadImage(file);
        await sendFileToServer(formData, img, file.name, controllerLocation, editorInstance);
    } catch (error) {
        console.error('Error processing image:', error);
    }
}

function loadImage(file) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = function () {
            URL.revokeObjectURL(img.src);
            resolve({ img, width: img.width, height: img.height });
        };
        img.onerror = reject;
        img.src = URL.createObjectURL(file);
    });
}

async function sendFileToServer(formData, { img, width, height }, fileName, controllerLocation, editorInstance) {
    try {
        const response = await fetch(`${controllerLocation}/file/manager/upload`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error(`Server error: ${response.status} ${response.statusText}`);
        }

        const result = await response.json();
        insertImage(result.location, fileName, width, height, editorInstance);
    } catch (error) {
        console.error('Error uploading file:', error);
    }
}

function insertImage(src, alt, width, height, editorInstance) {
    const sanitizedAlt = sanitizeHTML(alt);
    editorInstance.insertContent(
        `<img src="${src}" alt="${sanitizedAlt}" width="${width}" height="${height}">`
    );
}

function sanitizeHTML(str) {
    const temp = document.createElement('div');
    temp.textContent = str;
    return temp.innerHTML;
}

function initEditorUtils($, options, self) {
    return self = {
        options: options,
        dictionary: options.dictionary || {},
        colorsUrl: options.controllerLocation.concat('/htmleditor/colors'),
        companyColorsUrl: options.controllerLocation.concat('/htmleditor/colors/company-colors'),
        editorColorMap: {
            isFetched: false,
            colors: [...BASE_COLORS],
        },
        tablePresetsUrl: options.controllerLocation.concat('/table-preset'),
        validationSanitization: com.kms.web.editor.validationSanitization,
        isLinkPluginDialog: false,
        advtableValueSeries: {
          numbers: {
            title: 'Numeric',
            update: true,
            resizable: false,
            generator: function (info, rowIndex, colIndex) {
              const prevCount = info.prev?.count || 0;

              if (info.sectionType === 'tbody' && info.cellType === 'td') {
                const newCount = prevCount + 1;
                return { value: newCount, count: newCount };
              }

              return { value: '', count: prevCount };
            }
          },
          alpha: {
            title: 'Alpha',
            update: true,
            resizable: false,
            generator: function (info, rowIndex, colIndex) {
              const lastCount = info.prev?.lastCount ?? 1;

              function generateAlphaIndex(number) {
                let alphaIndex = '';
                while (number > 0) {
                  let remainder = (number - 1) % 26;
                  alphaIndex = String.fromCharCode(65 + remainder) + alphaIndex;
                  number = Math.floor((number - 1) / 26);
                }
                return alphaIndex;
              }

              if (info.sectionType !== 'tbody' || info.cellType !== 'td') {
                return {value: '', lastCount: lastCount };
              }

              const value = generateAlphaIndex(lastCount);
              return { value: value, lastCount: lastCount + 1 };
            }
          },
        },

        hideMediaSourceButton: function (editor) {
            document.querySelector('.tox-dialog').classList.add('tox--upload-btn-invisible');
        },

        addCommandListeners: function(editor) {
            editor.on('ExecCommand', (event) => {
                if (event.command === 'mceMedia') {
                    self.hideMediaSourceButton();
                }
                self.isLinkPluginDialog = event.command === 'mceLink';
            });
        },

        fixLinkTargets: function ($editorContent) {
            $editorContent.find('a').each(function () {
                $(this).attr('data-tinymce-link', '');
            });
        },

        checkValidExtension: function (file) {
            var allowedExtension = options.allowedFileExtensions.split(',');
            return allowedExtension.some(function(ext) {
                return file.indexOf(ext) !== -1
            });
        },

        getAllowedImageExtensions: function () {
            return self.options.allowedImageExtensions.reduce(function (initVal, ext) {
               return initVal + ext.replace('%', '') + ',';
            }, '')
        },

        getLanguage: function (locale) {
            //e.g. iw_IL -> iw
            locale = locale.toLowerCase();

            return {
                iw: 'he',
                ru: 'ru',
            }[locale] || locale;
        },

        changeListFont: function (ed) {
            return function(evt) {
                var cmd = evt.command;
                var LIST_OF_EVTS = {
                    FontSize: 'FontSize',
                    FontName: 'FontName',
                };

                if (!LIST_OF_EVTS[cmd]) return;

                var val = evt.value;
                var node = evt.target.selection.getNode();
                var nodeName = node.nodeName;
                var nodeParent = node.parentNode;
                var changedValue = cmd === LIST_OF_EVTS.FontSize ? 'font-size' : 'font-family';

                var startNode = getLi(evt.target.selection.getStart().parentNode);
                var endNode = getLi(evt.target.selection.getEnd().parentNode);

                if (startNode && startNode !== endNode) {

                    var startNodeIndex;
                    var endNodeIndex;

                    node.childNodes.forEach(function (n, index) {
                        if (startNode === n) {
                            startNodeIndex = index;
                        }

                        if (endNode === n) {
                            endNodeIndex = index;
                        }

                        if (startNodeIndex <= index || endNodeIndex >= index) {
                            ed.dom.setStyle(n, changedValue, val);
                        }
                    });
                }

                if (nodeName === NODE_NAMES.span && nodeParent.nodeName === NODE_NAMES.li) {
                    ed.dom.setStyle(nodeParent, changedValue, val);
                } else if(nodeName === NODE_NAMES.ul && nodeName === NODE_NAMES.ol) {
                    var li = ed.dom.select('li', node);
                    ed.dom.setStyle(li, changedValue, val);
                }
            }
        },

        getUploadUrl: function (context) {
            var url = self.options.controllerLocation.concat('/file/manager/upload');
            var queryString = self.getQueryString(context);
            return url.concat('?', queryString);
        },

        getControllerLocation: function () {
            return self.options.controllerLocation;
        },

        getQueryString: function (context) {
            var queryString = '';
            if (context.hasOwnProperty('node')) {
                if (/^\d+$/.test(context.node.stepId)) {
                    // new scenario steps, which has fake ids starting from "node_" shouldn't pass itemId
                    queryString = $.param({
                        itemId: context.node.stepId
                    });
                } else {
                    // otherwise we need to pass
                    queryString = $.param({
                        parentId: context.itemId,
                        itemVersion: context.itemVersion
                    });
                }
            } else {
                queryString = $.param({
                    itemId: context.itemId,
                    itemVersion: context.itemVersion,
                    itemRevision: context.itemRevision
                });
            }
            return queryString;
        },

        getTermClass: function (status) {
            switch (status) {
                case 1:
                    return 'glossary-term--offline';
                case 3:
                    return 'glossary-term--hidden';
                case 4:
                    return 'glossary-term--archive';
                default:
                    return '';
            }
        },

        createAutocompleteItem: function (it) {
            return {
                type: 'cardmenuitem',
                value: it,
                label: it.name,
                items: [
                    {
                        type: 'cardcontainer',
                        direction: 'vertical',
                        items: [
                            {
                                type: 'cardtext',
                                text: it.name,
                                name: 'char_name',
                                classes: self.getTermClasses(it.status),
                            },
                        ]
                    }
                ],
            };
        },

        getTermClasses: function (status) {
            var itemClass = self.getTermClass(status)
            if (itemClass) {
                return [itemClass]
            }
            return []
        },

        // fetches Glossary autocomplete items, if triggered multiple times, cancels previous ongoing requests
        searchTerms: function (pattern) {
            if (fetchController) {
                fetchController.abort();
            }
            if (AbortController) {
                fetchController = new AbortController();
                var signal = fetchController.signal;
            }
            return new tinymce.util.Promise(function (resolve) {
                self.fetchTerms({ query: pattern }, function (data) {
                    resolve(data.map(self.createAutocompleteItem));
                }, signal);
            });
        },

        fetchTerms: function (data, callback, signal) {
            $.ajax({
                url: self.options.controllerLocation + '/glossary/search',
                type: 'get',
                beforeSend: createJqueryAjaxAbortAdapter(signal),
                data: {
                    query: data.query || '*',
                    matchWords: false,
                    page: 1,
                    limit: data.query ? options.glossaryTermsAutocompleteLimit || 1000 : 10,
                    onlyTitle: true,
                    searchLanguage: _top.com.kms.web.ml.itemLang,
                }
            })
            .then(function (res) {
                if (res && res.data && res.data.terms) {
                    if (res.data.terms.length) {
                        callback(res.data.terms.map(function (it) {
                            return {
                                id: it.id,
                                name: it.title,
                                className: self.getTermClass(it.status),
                                status: it.status
                            }
                        }))
                    } else {
                        callback([{name: self.options.dictionary.nothingFound, id: null}])
                    }
                }
            });
        },

        getColors: function() {
            $.ajax({
                url: self.colorsUrl,
                async: false,
                dataType: 'json',
                type: 'get',
                success: function (res) {
                    localStorage.setItem('tinymce-custom-colors', JSON.stringify(res));
                }
            });
        },

        fillCompanyColors: function(colorList) {
            // Define a regular expression to match valid hexadecimal color codes
            const hexColorRegex = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
            // Filter the input colorList to keep only valid hex colors, then limit to the first 10
            const filteredColors = colorList.filter(color => hexColorRegex.test(color)).slice(0, 10);
            // Create a new array with each color repeated twice: once as-is and once in uppercase
            const companyColorList = filteredColors.flatMap(color => [color, color.toString().toUpperCase()]);
            // Combine the base colors with the company colors and assign to the editorColorMap
            self.editorColorMap.colors = BASE_COLORS.concat(companyColorList);
        },

        fetchCompanyColors: async function() {
            if (!self.editorColorMap.isFetched) {
                await $.ajax({
                    url: self.companyColorsUrl,
                    async: true,
                    dataType: 'json',
                    type: 'get',
                    success: function (res) {
                        if (res && res.length) {
                            self.fillCompanyColors(res);
                        }
                    },
                    complete: function () {
                        self.editorColorMap.isFetched = true;
                    },
                });
            }
        },

        addColors: function () {
            return function (callback, colors) {
                $.ajax({
                    url: self.colorsUrl,
                    async: false,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'post',
                    processData: false,
                    data: JSON.stringify(colors),
                    success: function (res) {
                        callback(res);
                    }
                });
            }
        },

        removeColors: function () {
            return function (callback, colors) {
                $.ajax({
                    url: self.colorsUrl,
                    async: false,
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'delete',
                    processData: false,
                    data: JSON.stringify(colors),
                    success: function (res) {
                        callback(res);
                    }
                });
            }
        },

        getItemLanguage: function(options) {
            return function () {
                return options.context.language;
            }
        },

        getItemContext: function (self) {
            return function () {
              return self.context;
            }
        },

        formats: {
            divformat: { block: 'div', styles: { background: '', border: '', padding: ''}, exact: true },
            h1format: { block: 'h1', styles: { background: '', border: '', padding: ''}, exact: true },
            h2format: { block: 'h2', styles: { background: '', border: '', padding: ''}, exact: true },
            h3format: { block: 'h3', styles: { background: '', border: '', padding: ''}, exact: true },
            h4format: { block: 'h4', styles: { background: '', border: '', padding: ''}, exact: true },
            h5format: { block: 'h5', styles: { background: '', border: '', padding: ''}, exact: true },
            h6format: { block: 'h6', styles: { background: '', border: '', padding: ''}, exact: true },
            pformat: { block: 'p', styles: { background: '', border: '', padding: ''}, exact: true },
            preformat: { block: 'pre', styles: { background: '', border: '', padding: ''}, exact: true },
            specialformat: { block: 'div', styles: { background: '#eeeeee', border:'1px solid #cccccc', padding: '5px 10px' }, exact: true, },
        },

        styleFormats : [
            { title: 'Paragraph', format: 'pformat' },
            { title: 'Heading 1', format: 'h1format' },
            { title: 'Heading 2', format: 'h2format' },
            { title: 'Heading 3', format: 'h3format' },
            { title: 'Heading 4', format: 'h4format' },
            { title: 'Heading 5', format: 'h5format' },
            { title: 'Heading 6', format: 'h6format' },
            { title: 'Preformatted', format: 'preformat' },
            { title: 'Div', format: 'divformat' },
            { title: 'Special Container', format: 'specialformat' },
        ],

        fonts: {
            'Open Sans':'open sans',
            'Helvetica':'helvetica',
            'Lucida Unicode':'lucida sans unicode',
            'Calibri':'calibri',
            'Andale Mono':'andale mono,times',
            'Arial':'arial,helvetica,sans-serif',
            'Arial Black':'arial black,avant garde',
            'Book Antiqua':'book antiqua,palatino',
            'Comic Sans MS':'comic sans ms,sans-serif',
            'Courier New':'courier new,courier',
            'Georgia':'georgia,palatino',
            'Impact':'impact,chicago',
            'Symbol':'symbol',
            'Tahoma':'tahoma,arial,helvetica,sans-serif',
            'Terminal':'terminal,monaco',
            'Times New Roman':'times new roman,times',
            'Trebuchet MS':'trebuchet ms,geneva',
            'Verdana':'verdana,geneva',
            'Webdings':'webdings',
            'Wingdings':'wingdings,zapf dingbats'
        },

        fontsizeFormats: ['8px', '9px', '10px', '11px', '12px', '13px', '14px', '15px', '16px', '18px', '20px', '21px', '22px', '24px', '26px', '28px', '36px', '48px'],

        lineHeightFormats: '1 1.1 1.2 1.3 1.4 1.5 2',

        Delimiter: {
            SemiColon: 0,
            Space: 1,
        },

        invalidStyleElements: {
            'h1': 'font-size',
            'h2': 'font-size',
            'h3': 'font-size',
            'h4': 'font-size',
            'h5': 'font-size',
            'h6': 'font-size'
        },

        /**
         * Get the list of fonts (Story LAS-38139).
         *
         * This function returns a list of fonts based on the customer's settings.
         * The customer's settings are determined by the 'kms.application.editor.customer.fonts.enabled' property.
         *
         * @returns {Object} - An object containing the list of fonts.
         */
        getFontsList: function() {
            return self.options.isCustomerFontsEnabled ? {...self.options.customerFonts, ...self.fonts} : self.fonts;
        },

        /**
         * Returns `fontsize_formats`setting for tinymce with marking of default value.
         * Example: "14px (Default)=14px;16px;20px"
         *
         * @returns {string}
         */
        getFontSizeFormats: function() {
            var defaultStyles = self.getDefaultStyles();
            var values = self.fontsizeFormats.map(function(value) {
                if (value === defaultStyles['font-size']) {
                    value += ' (' + self.options.dictionary.default + ')=' + value;
                }

                return value;
            });

            return values.join(';');
        },

        /**
         * Returns `style_formats`setting for tinymce with marking of default value.
         * Example: [ { title: 'Paragraph', format: 'pformat' }, { title: 'Heading 1', format: 'h1format' } ]
         *
         * @returns {({ title: string, format: string })[]}
         */
        getStyleFormats: function() {
            return self.styleFormats.map(function(format) {
                var title = format.title;

                if (title === self.options.default.format) {
                    title += ' (Default)';
                }

                return { title: title, format: format.format };
            });
        },

        /**
         * Returns `font_formats` setting for tinymce with marking of default value.
         * Example: "Arial (Default)=arial,helvetica,sans-serif;Open Sans=Open Sans"
         *
         * @returns {string}
         */
        getFontFormats: function() {
            var fonts = self.getFontsList();
            var labels = Object.keys(fonts);
            var values = labels.map(function(label) {
                var value = fonts[label];

                if (label === self.options.default.font) {
                    label += ' (' + self.options.dictionary.default + ')';
                }

                return [ label, value ].join('=');
            });

            return values.join(';');
        },

        /**
         * Returns default styles from application properties.
         *
         * @returns { ({'font-family': string, 'font-size': string, 'line-height': string}) }
         */
        getDefaultStyles: function() {
            var fonts = self.getFontsList();
            var defaults = self.options.default;
            var lineHeghts = self.lineHeightFormats.split(' ');
            var font = fonts[defaults.font] ? fonts[defaults.font] : fonts['Open Sans'];
            var fontSize = self.fontsizeFormats.includes(defaults.fontSize) ? defaults.fontSize : '14px';
            var lineHeight = lineHeghts.includes(defaults.spacing) ? defaults.spacing : '1';

            return {
                'font-family': font,
                'font-size': fontSize,
                'line-height': lineHeight,
            };
        },
        /**
         * Returns `forced_root_block` setting for tinymce with marking of default value.
         *
         * @returns {string}
         */
        getRootBlock: function() {
            switch(self.options.default.format) {
                case 'Div':
                    return 'div';
                case 'hr':
                    return 'hr';
                case 'Paragraph':
                default:
                    return 'p';
            }
        },

        /**
         * Returns default format
         * @returns { string | null }
         */
        getDefaultFormat: function() {
            var format = self.styleFormats.find(function(format) {
                return format.title === self.options.default.format;
            });

            if (!format) {
                format = self.styleFormats[0];
            }

            return format && format.format;
        },

        /**
         * Setup default styles in tinymce for some cases:
         * - set inline default styles when format is removed
         * - wrap content by div with inline default styles for pasted content and code block
         *
         * @param editor {Editor}
         */
        setupDefaultStyles: function(editor) {
            var defaultStyles = self.getDefaultStyles();
            var defaultStylesStr = new tinymce.html.Styles().serialize(defaultStyles);

            var getSelection = function(callback) {
                if (editor.selection.isCollapsed()) {
                    var node = editor.selection.getNode();
                    var bookmark = editor.selection.getBookmark();

                    editor.selection.select(node);
                    callback();
                    editor.selection.moveToBookmark(bookmark);
                }
                else {
                    callback();
                }
            };

            var applyDefaultStyles = function() {
                editor.undoManager.ignore(function() {
                    editor.formatter.apply(self.getDefaultFormat());
                    editor.execCommand('FontName', false, defaultStyles['font-family']);
                    editor.execCommand('FontSize', false, defaultStyles['font-size']);
                    editor.execCommand('LineHeight', false, defaultStyles['line-height']);
                });
            };

            editor.on('ExecCommand', function(e) {
                if (e.command === 'RemoveFormat') {
                    // wait for removing format is completed
                    self.nextTick(function() {
                        getSelection(applyDefaultStyles);
                    });
                }
            });

            editor.on('FormatApply', function (data) {
                const headers = ['h1format', 'h2format', 'h3format', 'h4format', 'h5format', 'h6format'];
                const tagNames = ['H1', 'H2', 'H3', 'H4', 'H5', 'H6'];
                const currentNode = editor.selection.getNode();

                if (headers.includes(data.format)) {
                    const selectedTag = currentNode.tagName;

                    if (tagNames.includes(selectedTag)) {
                        currentNode.style.removeProperty('font-size');
                    }
                    if (selectedTag === 'SPAN' && currentNode.style['font-size'] === defaultStyles['font-size']) {
                        const topElement = currentNode.parentNode.closest(tagNames.toString().toLowerCase());
                        topElement.style.removeProperty('font-size');
                        const nodeText = currentNode.textContent;
                        topElement.replaceChildren(nodeText);
                    }
                }
            });

            editor.on('ListMutation', function(e) {
                const selectedElement = e.element;

                if (selectedElement && e.action === 'ToggleUlList' && e.type === 'listmutation') {
                    const newStyleValue = selectedElement.style?.listStyleType;

                    if (newStyleValue === '') {
                        selectedElement.style.setProperty('list-style-type', 'disc');
                    }
                }
            });

            editor.on('BeforeSetContent', function(event) {
                // wrap content by span with default styles for pasted content and code block
                if (event.content && !event.set && event.format === 'html'
                    && (event.paste || event.content.match(/^<pre/i))
                ) {
                    event.content = '<span style="' + defaultStylesStr + '">' + event.content + '</span>';
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(event.content, 'text/html');

                    doc.querySelectorAll('[data-link-id]').forEach((element) => {
                        element.setAttribute('data-link-id', _top.uuid.v4());
                    });

                    event.content = doc.body.innerHTML;
                }
            });
        },

        addDefaultFormatToContent: function(content) {
            var defaultStyles = self.getDefaultStyles();
            var defaultStylesStr = new tinymce.html.Styles().serialize(defaultStyles);

            return content.replace(/<p>/g, `<p style="${defaultStylesStr}">`);
        },

        nextTick: function(callback) {
            setTimeout(callback, 0);
        },

        getFilePickerHandler: function (getContext) {
            return function (cb, value, meta) {
                var ctx = getContext();
                var uploadUrl = self.getUploadUrl(ctx);
                var input = document.createElement('input');

                input.setAttribute('type', 'file');

                input.onchange = function () {
                    var file = this.files[0];
                    var reader = new FileReader();

                    reader.onload = function () {
                        var id = 'blobid' + (new Date()).getTime();
                        var blobCache =  tinymce.activeEditor.editorUpload.blobCache;
                        var base64 = reader.result.split(',')[1];
                        var blobInfo = blobCache.create(id, file, base64);
                        blobCache.add(blobInfo);
                        var extensionLowerCase = '.' + file.name.split('.').pop().toLowerCase();

                        var uploadFile = function(metaInfo) {
                            var xhr;
                            var formData;

                            xhr = new XMLHttpRequest();
                            xhr.withCredentials = false;
                            xhr.open('POST', uploadUrl)
                            xhr.onload = function() {
                                var json;
                                if (xhr.status !== 200) {
                                    return;
                                }
                                json = getJson(xhr.responseText);
                                if (!json) {
                                    return;
                                }
                                cb(json.location, metaInfo);
                            };

                            formData = new FormData();
                            formData.append('file', blobInfo.blob(), file.name);

                            xhr.send(formData);
                        }

                        // check if file size less than max upload size
                        if (file.size < self.options.maxUploadSize) {
                            // file upload plugin
                            if (meta.filetype === 'file') {
                                if (self.checkValidExtension(extensionLowerCase)) {
                                    uploadFile({text: file.name})
                                } else {
                                    tinymce.activeEditor.windowManager.alert(self.dictionary.fileUploadFail)
                                }
                            }

                            // image upload plugin
                            if (meta.filetype === 'image') {
                                if (self.getAllowedImageExtensions().indexOf(extensionLowerCase) !== -1) {
                                    uploadFile({alt: file.name})
                                } else {
                                    tinymce.activeEditor.windowManager.alert(self.dictionary.invalidImageFormat)
                                }
                            }
                        } else {
                            var fileSize = Math.round(file.size / 1000000) + ' MB'
                            var maxUploadSize = Math.round(self.options.maxUploadSize / 1000000) + ' MB'
                            var msg = self.dictionary.maxFileSizeExceeded.replace('{0}', fileSize).replace('{1}', maxUploadSize)
                            tinymce.activeEditor.windowManager.alert(msg)
                        }
                    };
                    reader.readAsDataURL(file);
                };

                input.click();
            }
        },

        createAnchorContextMenu: function (editor) {
            editor.ui.registry.addMenuItem('remove_anchor', {
                text: 'Remove anchor',
                icon: 'remove',
                onAction: function () {
                    editor.execCommand('mceRemoveNode');
                }
            });

            editor.ui.registry.addContextMenu('anchor', {
                update: function (elm) {
                    if (self.isAnchor(elm)) {
                        return 'anchor remove_anchor'
                    }
                    return ''
                }
            });
        },
        getIdFromAnchor: function (elm) {
            var id = elm.getAttribute('id') || elm.getAttribute('name');
            return id || '';
        },
        isAnchor: function (elm) {
            return elm && elm.nodeName.toLowerCase() === 'a' &&
                !elm.getAttribute('href') &&
                self.getIdFromAnchor(elm) !== '';
        },

        // TODO: move to separate file
        dialogValidation: {
            /**
             * @param $dialog {JQuery<HTMLElement>}
             */
            $dialog: null,

            /**
             * @param dialogApi {InstanceApi}
             */
            dialogApi: null,

            /**
             * @param dialogFieldNames {Record<string, string[]>}
             */
            dialogFieldNames: {
                'Insert/Edit Link': ['url', 'text', 'title', 'emailAddress', 'emailSubject', 'emailMessage'],
                'Insert/Edit Media': ['source', 'embed', 'altsource', 'poster'],
                'Insert/Edit Image': ['src', 'alt'],
            },

            /**
             * @param relatedFields {Record<string, string[]>}
             */
            relatedFields: {
                // Link
                url: ['text'],
                emailAddress: ['url', 'text'],
                emailSubject: ['url'],
                emailMessage: ['url'],
                // Image
                src: ['alt'],
            },

            fieldSelector: '.tox-textfield, .tox-textarea',

            groupSelector: '.tox-form__group',

            tabSelector: '.tox-tab',

            activeTabSelector: '.tox-tab.tox-dialog__body-nav-item--active',

            invalidClass: 'invalid',

            isDialogNotValidated: false,

            /**
             * Validation results cache
             * @param validationResults {Record<string, boolean>}
             */
            validationResults: {},

            /**
             * Map of validators by field name
             * @param validators {Record<string, (string) => Promise<boolean>>}
             */
            validators: {},

            /**
             * Setup editor dialog fields validation
             * @param editor {Editor}
             */
            init: function(editor) {
                var that = this;

                editor.on('OpenWindow', function(e) {
                    const htmlString = e.dialog.getData().codeview;
                    if (htmlString) {
                        that.htmlString = htmlString;
                    }
                    that.$dialog = $('.tox-dialog');
                    that.dialogApi = e.dialog;

                    if(!that.isValidateDialog()) return;

                    that.validators = that.getValidators();
                    that.setFieldsValidation();
                });

                editor.on('CloseWindow', function(e) {
                    const htmlString = e.dialog.getData().codeview;

                    if (htmlString && that.htmlString !== htmlString) {
                        const updatedHtmlString = that.updateDataLinks(htmlString);
                        tinymce.activeEditor.execCommand('mceSetContent', false, updatedHtmlString);
                    }

                    that.$dialog = null;
                    that.dialogApi = null;
                    that.validationResults = {};
                    that.validators = {};
                    self.isItemIdExists = false;
                });
            },


            /**
             * Update all data-link-id, to prevent it doubling, while copy-paste
             * @returns {string}
             */
            updateDataLinks: function(htmlString) {
                const domParser = new DOMParser();
                const document = domParser.parseFromString(
                    `<article>${htmlString}</article>`,
                    'text/html'
                );

                const elementsWithLinkId = document.querySelectorAll('[data-link-id]');

                elementsWithLinkId.forEach(element => {
                    element.dataset.linkId = _top.uuid.v4();
                });

                return document.querySelector('article').innerHTML;
            },


            /**
             * Check current dialog fields should be validated
             * @returns {boolean}
             */
            isValidateDialog: function() {
                var name = this.$dialog.data('name');

                return Object.keys(this.dialogFieldNames).includes(name);
            },

            /**
             *
             * @returns { string[] | undefined }
             */
            getDialogFieldNames: function() {
                var name = this.$dialog.data('name');

                return this.dialogFieldNames[name];
            },

            /**
             * Validate value by sending request or getting result from cache
             * @param value {string}
             * @returns {Promise<boolean>}
             */
            isValid: function(value) {
                var that = this;

                // empty value is valid
                if(!value) {
                    return Promise.resolve(true);
                }

                // get validation result from cache
                if(typeof this.validationResults[value] !== 'undefined') {
                    return Promise.resolve(this.validationResults[value]);
                }

                return self.validationSanitization
                    .securityCall(value, 'validation')
                    .then(function(res) {
                        var isValid = res.status === 'SUCCESS';
                        // put validation result to cache
                        that.validationResults[value] = isValid;

                        return isValid;
                    });
            },

            /**
             * Returns debounced validators for each field
             * @returns {Record<string, (string) => Promise<boolean>>}
             */
            getValidators: function() {
                var that = this;

                var validator = function(el) {
                    that.isValid(el.value).then(function(isValid) {
                        // exit when dialog is closed
                        if (!that.$dialog) return;

                        that.setValidationResult(el, isValid);
                        self.toggleSaveButton();
                    });
                };

                var fieldNames = this.getDialogFieldNames();

                return fieldNames.reduce(function(validators, name) {
                    validators[name] = _.debounce(validator, 500);

                    return validators;
                }, {});
            },

            /**
             * Validate field
             * @param el {HTMLElement}
             * @param name {string}
             */
            validateField: function(el, name) {
                if (!name || !this.validators[name]) return;

                this.validators[name](el);
            },

            /**
             * Validate related fields
             * @param name {string}
             */
            validateRelatedFields: function(name) {
                var that = this;

                if(!this.relatedFields[name]) return;

                this.relatedFields[name].forEach(function(name) {
                    var el = that.$dialog
                        .find(that.fieldSelector)
                        .filter('[data-name="' + name + '"]')
                        .get(0);

                    if (!el) return;

                    that.validateField(el, name);
                });
            },

            /**
             * Find all fields in current tab and validate them
             */
            validateAllFields: function() {
                var that = this;
                var $fields = that.$dialog.find(that.fieldSelector);
                // validate all fields on current tab as fields are re-rendered
                $fields.each(function() {
                    var name = $(this).data('name');

                    that.validateField(this, name);
                    that.validateRelatedFields(name);
                });
            },

            /**
             * Init dialog fields validation
             */
            setFieldsValidation: function() {
                var that = this;

                // custom event `form-component-change` used for detecting field changes after file upload
                this.$dialog.on('form-component-change', function(event) {
                    // target should be form group in this case
                    if (!$(event.target).is(that.groupSelector)) return;

                    var el = $(event.target).find(that.fieldSelector).get(0);
                    var name = event.originalEvent.detail.name;

                    that.validateField(el, name);
                    that.validateRelatedFields(name);
                });

                // field is changed
                this.$dialog.on('input', that.fieldSelector, function(event) {
                    var el = event.target;
                    var name = $(el).data('name');

                    that.validateField(el, name);
                    that.validateRelatedFields(name);

                    if (el.getAttribute('data-name') === 'itemID') {
                      self.isItemIdExists = el.value !== '';
                    }
                });

                // tab is changed
                this.$dialog.on('click', that.tabSelector, function() {
                    // wait tab is changed
                    self.nextTick(function() {
                        that.validateAllFields();
                    });
                });

                this.$dialog.on('keydown', function(e) {
                    // disable save by pressing 'enter' button if invalid fields
                    if (e.keyCode === 13 && that.isDialogNotValidated) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                });

                // validate all fields when dialog is opened
                self.nextTick(function() {
                    that.validateAllFields();
                });
            },

            /**
             * Apply validation result to fields
             * @param el {HTMLElement}
             * @param isValid {boolean}
             */
            setValidationResult: function(el, isValid) {
                $(el).toggleClass(this.invalidClass, !isValid);

                if (!isValid) {
                    this.setFieldIcon(el);
                }
            },

            /**
             * Add invalid state icon with tooltip to field.
             * @param input {HTMLElement}
             */
            setFieldIcon: function(input) {
                var $input = $(input);
                var name = $input.data('name');

                // only one icon per field
                if($input.data('isFieldValidationInit')) return;

                $input.data('isFieldValidationInit', true);

                var $icon = $('<i class="icon-attention">');

                $input.parent().append($icon);

                $icon.tooltipster({
                    theme: ['tooltipster-borderless', 'tooltipster-general'],
                    contentAsHTML: true,
                    content: self.validationSanitization.dictionary[name === 'url' ? 'invalidUrl' : 'invalidField'],
                });
            },
        },

        isItemIdExists: false,

        /**
         * Toggle save button
         * It's based on fields validation and item id existing in case of link plugin dialog
         *
         * @self.dialogValidation.isDialogNotValidated {boolean} - validation
         * @self.isLinkPluginDialog {boolean} - check if the dialog called by link plugin
         * @self.isItemIdExists {boolean} - item id exists
         */
        toggleSaveButton: function() {
          var inputs = self.dialogValidation.$dialog.find(self.dialogValidation.fieldSelector);
          var $invalidFields = inputs.filter('.' + self.dialogValidation.invalidClass);
          self.dialogValidation.isDialogNotValidated = $invalidFields.length > 0;

          var activeTab = self.dialogValidation.$dialog.find(self.dialogValidation.activeTabSelector);
          var isItemLinkTab = activeTab.text() === tinymce.util.I18n.translate('Item');

          var action = '';
          if (self.isLinkPluginDialog && isItemLinkTab) {
              action = self.dialogValidation.isDialogNotValidated || !self.isItemIdExists ? 'disable' : 'enable';
          } else {
              action = self.dialogValidation.isDialogNotValidated ? 'disable' : 'enable';
          }

          self.dialogValidation.dialogApi[action]('save');
        },

        intervalCleaner : function(that) {
            clearInterval(that.validationParams.validationIntervalId);
            that.validationParams.validationIntervalId = null;
        },

        /**
         * Create a cursor helper to then put it in the right spot.
         * @param {object} editor - tinyMCE editor instance.
         */
        _createCaretPositionHelper : function (editor) {
            const caretPositionHelper = '<span id="_mce_caret_helper"\/>';

            editor.selection.collapse(false);
            editor.selection.setContent(caretPositionHelper);
        },

        /**
         * Hack to put the cursor in the right spot.
         * @param {object} editor - tinyMCE editor instance.
         */
        _returnCaretPositionHelper : function (editor) {
            editor.focus(); //give the editor focus
            editor.selection.select(editor.dom.select('#_mce_caret_helper')[0]); //select the inserted element
            editor.selection.collapse(false); //collapses the selection to the end of the range, so the cursor is after the inserted element
        },

        /**
         * Hack to create element with "absolute" position and attach a tooltip to it.
         * @param {object} editor - tinyMCE editor instance.
         */
        _createTooltipsterForErrors : function (editor) {
            const errorMessageTooltipClassName = 'errorMessageTooltip';

            $(editor.getBody()).find('err').each(function() {
                const $err = $(this);

                $err.on('mouseenter', function(e) {
                    // get current editor context iframe element
                    const frameElement = e.view.frameElement;

                    // find current frame element offset relative to parent iframe
                    const frameElementRect = frameElement.getBoundingClientRect();

                    // find current frame element scroll value
                    const framePageYOffset = frameElement.contentWindow.pageYOffset;

                    // the offset for the new element that the tooltipster will apply to
                    // window.pageYOffset - parent dialog iframe scroll value
                    const offsetTop = frameElementRect.top - framePageYOffset + window.pageYOffset;
                    const offsetLeft = frameElementRect.left;

                    if ($(`.${errorMessageTooltipClassName}`).length === 0) {
                        $(`<div class="${errorMessageTooltipClassName} kms-helper-absolute"\/>`)
                            .appendTo('body')
                            .tooltipster({
                                trigger: 'custom',
                                theme: ['tooltipster-borderless', 'tooltipster-general'],
                                content: self.validationSanitization.dictionary.fullScreenEditor.errorTooltipText,
                                contentAsHTML: true,
                                delay: 350
                            })
                            .position({
                                my:        `center+${offsetLeft}`,
                                at:        `center top+${offsetTop}`,
                                of:        $err,
                                collision: "fit"
                            })
                            .tooltipster('open');
                    }
                }).on('mouseleave', function(e) {
                    if (e.relatedTarget.tagName !== 'ERR') {
                        $(`.${errorMessageTooltipClassName}`)
                            .filter('.tooltipstered')
                            .tooltipster('destroy')
                            .remove();
                    }
                });
            })
        },

        /**
         * clear content from <err> tags before submit to avoid re-adding this tags.
         * @param {string} content - content of tinyMCE editor instance.
         */
        _cleanErrTagFromContent : function (content) {
            const $content = $($.parseHTML(content));

            $content.find('err').each(function(){
                const $el = $(this);
                if ( $el.length > 0 ) this.outerHTML = $el.text();
            })

            return self._createNewContentFromDom($content);
        },

        /**
         * Function that converts $DOM object into content of the tinyMCE format.
         * @param {object} $dom - $DOM object to be converted.
         *
         * @returns {string} new content in the format required for further placement in the editor.
         */
        _createNewContentFromDom : function ($dom) {
            let newContent = '';
            $dom.each(function(){
                const hasVideo = this.children && Array.from(this.children).some(i => i.nodeName === 'VIDEO');

                const htm = this.textContent === '\n' && !hasVideo ? '\n' : this.outerHTML;
                newContent = newContent + htm;
            })

            return newContent;
        },

        /**
         * Function that performs  necessary value conversions before it is sent to the server.
         * @param {string} value to be converted.
         *
         * @returns {string} new value ready to be sent to the server.
         */
        prepareDataBeforeSecurityCall : function (value) {
            value = self._cleanErrTagFromContent(value);
            value = $.kmsSanitizeContent(value);
            const $value = $('<div>').hide().html(value);

            self.fixLinkTargets($value);

            value = $value.html().replace(/\[~.*&amp;.*\]/g, function(string) {
                return string.replace('&amp;', '&');
            });

            // all URL encoded symbols like "%20" in urls should be decoded for passing the validation (except %22 symbol, see LAS-32006)
            return value.replace(/(?:src|href)=(?:"|\')([^"']+)(?:"|\')/g, function ($1) {
                var result = '';

                $1 = $1.replace(/%22/g, '@@22@@')

                try {
                    result = decodeURI($1);
                } catch (e) {
                    // some uri can't be decoded. see LAS-2935
                    result = $1;
                }

                result = result.replace(/@@22@@/g, '%22');

                if (result.includes('mailto:')) {
                    result = result.replace(/\n/g, '%0A');
                }

                return result;
            });
        },

        /**
         * Function which validate TinyMCE content.
         * @param {object} that - context options instance.
         * @param {object} editor - tinyMCE editor instance.
         * @param {boolean} isInitialValidation - flag defines is it Initial Validation.
         */
        validateTinyMCEContent : function (that, editor, isInitialValidation) {
            if (!isInitialValidation) self._createCaretPositionHelper(editor);

            const preparedData = self.prepareDataBeforeSecurityCall(editor.getContent());
            const invalidCharactersCount = that.editor.validationParams.invalidCharactersCount;

            self.validationSanitization.validate(preparedData)
                .then(function(response){
                    self.onValidationSuccess(response, editor, that);
                })
                .catch(function (response) {
                    self.onValidationError(response, editor, that);
                })
                .finally(function () {
                    editor.dom.remove('_mce_caret_helper'); //remove the temp cursor helper
                    that.editor.validationParams.cachedContent = editor.getContent();

                    if (isInitialValidation && that.editor.validationParams.startupInvalidState !== undefined) {
                        that.editor.validationParams.startupInvalidState = that.editor.validationParams.invalidCharactersCount > 0;
                    }

                    if (invalidCharactersCount !== that.editor.validationParams.invalidCharactersCount) {
                        const eventName = `${self.validationSanitization.options.context}.validationMessage.change`;
                        $(document).trigger(eventName, that);
                    }
                })
        },

        /**
         * TinyMCE Editor Validation Error callback.
         * @param {object} response - validate promise result.
         * @param {object} editor - tinyMCE editor instance.
         * @param {object} that - context options instance.
         */
        onValidationError : function (response, editor, that) {
            const $domWithErrors = $($.parseHTML(response.resultValue));
            const $errors = $domWithErrors.find('err');

            //  disable preview button
            self.setButtonDisabledState(editor, 'Preview', true);

            that.editor.validationParams.invalidCharactersCount = $errors.length;

            $errors.each(function() {
                $(this).css('background-color', '#FFC3BF').addClass('mceNonEditable');
            });

            const newContent = self._createNewContentFromDom($domWithErrors);

            editor.setContent(newContent);
            self._returnCaretPositionHelper(editor);

            self._createTooltipsterForErrors(editor);
        },

        /**
         * TinyMCE Editor Validation Success callback.
         * @param {object} response - validate promise result.
         * @param {object} editor - tinyMCE editor instance.
         * @param {object} that - context options instance.
         */
        onValidationSuccess : function (response, editor, that) {
            //  enable preview button
            self.setButtonDisabledState(editor, 'Preview', false);

            if (that.editor.validationParams.invalidCharactersCount > 0) {
                that.editor.validationParams.invalidCharactersCount = 0;
            }
        },

        /**
         * Function which define TinyMCE editor validation interval.
         * @param {object} e - original event.
         * @param {object} that - context options instance.
         */
        // TODO: decompose it later
        setValidationInterval : function (e, that) {
            const validationInterval = self.validationSanitization.options.validationInterval;
            const eventName = `${self.validationSanitization.options.context}.validation.start`;

            if (!that.editor.validationParams.validationIntervalId) {
                const options = {
                    'isInitial' : false,
                    'target' : that
                };

                that.editor.validationParams.validationIntervalId = setInterval(function(){
                    $(document).trigger(eventName, options);
                }, validationInterval);
            }
            clearTimeout(that.editor.validationParams.clearingTimeoutId);

            that.editor.validationParams.clearingTimeoutId = setTimeout(function(){
                self.intervalCleaner(that.editor);
            }, validationInterval);
        },

        /**
         * Function which clears TinyMCE editor validation interval and calls its validation at the same time.
         * @param {object} e - original event.
         * @param {object} that - context options instance.
         */
        // TODO: decompose it later
        clearValidationInterval : function (e, that) {
            // paste and 'special charters' insert
            const eventName = `${self.validationSanitization.options.context}.validation.start`;

            if (e.originalEvent && e.originalEvent.command === "mceInsertContent") {
                const options = {
                    'isInitial' : false,
                    'target' : that
                };

                self.intervalCleaner(that.editor);
                $(document).trigger(eventName, options);
            }
        },

        /**
         * success preSave Fullscreen dialog callback.
         * @param {string} resultValue - sanitized data.
         * @param {object} that - "full-screen-editor" instance.
         * @param {callback} callback.
         */
        fullScreenDialogSaveCallback : function (resultValue, that, callback) {
            that.options.context.callback.setContent(resultValue);

            if (that.editor.isAiGenerationCalled) {
                that.options.context.callback.setAiGeneratedEditorSuggestionMessage(that.editor.isAiGenerated);
                that.editor.isAiGenerationCalled = false;
            }

            that.options.context.callback.applySanitizedState();

            that.editor.instance.resetContent();
            // reset all undo levels in undoManager
            // self.editor.instance.undoManager.clear & ..undoManager.clear are not working! LAS-18427
            tinymce.activeEditor.undoManager.clear();

            // give some time for complete callback from validateHtml method to execute;
            // otherwise IE9 throws a javascript error, because the editor iframe is removed
            setTimeout(function() {
                that.editor.closeDialog();
                if (callback) {
                    callback();
                }
            }, 0);
        },

        /**
         * Close dialog callback if Fullscreen editor contains invalid characters.
         * @param {object} that - "full-screen-editor" instance.
         */
        closeFullScreenDialogWithInvalidCharacters : function (that) {
            const content = that.editor.startupValue;

            self.validationSanitization.dialog(content, 'fullscreenEditor', that)
                .then(function(result) {
                    $(document).trigger('fullscreenEditor.validationMessage.hide');

                    // apply table presets
                    const fetchAndApplyPresets = com.kms.web.editor.presets.fetchAndApplyPresets;

                    fetchAndApplyPresets(result.resultValue)
                        .then(function(updatedValue) {
                            // set editor data
                            self.fullScreenDialogSaveCallback(updatedValue, that);
                        })
                        .catch(function(e) {
                            // TODO: implement error handler
                            console.error(e);
                        });
                });
        },

        /**
         * Function that updates the validation message.
         * @param {object} $message - Message instance.
         * @param {number} invalidCharactersCount - count of invalid characters.
         */
        refreshValidationMessage : function ($message, invalidCharactersCount) {
            const isContainInvalidCharacters = invalidCharactersCount > 0 ? true : false;
            if (!isContainInvalidCharacters) return $message.hide();

            const context = self.validationSanitization.options.context;
            const dictionaryInstance = context === 'inlineEditor'
                ? self.validationSanitization.dictionary.inlineEditor.errorMessageText
                : self.validationSanitization.dictionary.fullScreenEditor.errorMessageText;

            const messageElementId = $message.attr('id');
            const messageTextClassName = `.${messageElementId}--text`;

            const messageText = self._createValidationErrorMessageText(dictionaryInstance, invalidCharactersCount);

            $message.find(messageTextClassName).text(messageText);
            $message.show();
        },

        /**
         * Function that generates a message text that the content contains invalid characters.
         * @param {string} dictionaryInstance - the text in which to substitute parameters.
         * @param {number} invalidCharactersCount - invalid characters count.
         *
         * @returns {string} error message text.
         */
        _createValidationErrorMessageText : (dictionaryInstance, invalidCharactersCount) => {
            return dictionaryInstance.replace(/\{r\}/, invalidCharactersCount)
                .replace(/\{s\}/, invalidCharactersCount > 1 ? 's' : '');
        },

        /**
         * Function that generates a base validation error message markup.
         * @param {string} className - class name to be used for the message.
         *
         * @returns {string} error message markup.
         */
        createValidationErrorMessageMarkup : function (className) {
            return '<div class="' + className + '" id="' + className + '" style="display: none">' +
                    '<span class="kms-icon kms-icon--32 kms-icon--attention ' + className + '--icon"\/>' +
                    '<span class="' + className + '--text"\/>' +
                '</div>';
        },

        /**
         * Function that helps to propagate attributes to hidden buttons, appears after pressing the 'More...' button.
         * @param {object} editor - tinyMCE editor instance.
         */
        createActionsForMoreButton : function (editor) {
            const translatedMoreButtonName = tinymce.util.I18n.translate("More...");

            $(editor.getContainer()).find(`[aria-label="${translatedMoreButtonName}"]`)
                .click(function () {
                    setTimeout(function() {
                        const translatedPreviewButtonName = tinymce.util.I18n.translate("Preview");
                        const $previewButton = $(editor.getContainer()).find(`[aria-label="${translatedPreviewButtonName}"]`);
                        const isDisabled = $previewButton.prop('disabled');

                        $previewButton.attr('aria-disabled', isDisabled);
                    }, 0)
                });
        },

        /**
         * Function that helps disable or enable buttons on TinyMCE toolbar.
         * @param {object} editor - tinyMCE editor instance.
         * @param {string} name - button name.
         * @param {boolean} isDisabled - flag that defined what need to do with button (enable or disable).
         */
        setButtonDisabledState : function (editor, name, isDisabled) {
            const translatedButtonName = tinymce.util.I18n.translate(name);

            $(editor.getContainer()).find(`[aria-label="${translatedButtonName}"]`)
                .attr('aria-disabled', isDisabled)
                .prop('disabled', isDisabled);
        },

        // TODO: move table-related utils to separate file
        /**
         * Function that finds class with table preset REGEX from class list.
         * @param {DOMTokenList} classList - DOMTokenList collection of the class attributes of the table.
         * @param {string} regex - constant value of table preset REGEX.
         * @returns {string} class name of certain table preset.
         */
        findPresetClass: function (classList, regex) {
            var tableClassList = Array.from(classList);

            return tableClassList.find((className) => className.indexOf(regex) >= 0);
        },

        /**
         * Function that gets and parses table presets from sessionStorage.
         * @returns {array} table presets or empty array.
         */
        getPresets: function() {
            try {
                var presets = JSON.parse(sessionStorage.getItem('table-presets'));
                return presets.map(p => ({ ...p, preset: JSON.parse(p.preset) }));
            } catch {
                return [];
            }
        },

        /**
         * Function that creates list of table presets for dropdown.
         * @param {array} table - table presets.
         * @returns {array} list of table presets.
         */
        prepareTablePresetsList: function(presets) {
            var tablePresetsList = [
                { title: 'None', value: 'reset-preset' },
            ];

            var availablePresets = presets.filter((preset) => !preset.deleted);

            availablePresets.forEach(function(preset) {
                tablePresetsList.push({ title: preset.name, value: 'table-preset-' + preset.id });
            });

            return tablePresetsList;
        },

        /**
         * Function that sets table preset id based on TinyMCE class of preset.
         * @param {object} table - object of table from event.
         * @returns {string} table preset id.
         */
        setTablePresetAttr: function(table) {
            var tableClass = this.findPresetClass(table.classList, PRESET_REGEX)

            if (tableClass) {
                var tablePresetId = Number(tableClass.replace(PRESET_REGEX, ''));
                table.setAttribute(PRESET_REGEX + 'id', tablePresetId);
                return tablePresetId;
            } else {
                table.removeAttribute(PRESET_REGEX + 'id');
            }
        },

        /**
         * Function that updates and applies table preset if new was selected.
         * @param {object} table - object of table from event.
         * @param {array} presets - table presets.
         */
        updateTablePreset: function(table, presets) {
            var tablePresetId = this.setTablePresetAttr(table);

            if (tablePresetId) {
                var tablePreset = presets.find(function(preset) {
                    return preset.id === tablePresetId;
                });
                com.kms.web.editor.presets.applyTablePreset(tablePreset.preset, table);
            }
        },

        /**
         * Function that saves table preset in sessionStorage after opening table properties until save.
         * @param {HTMLElement} selectedNode - selected node, when user opened table properties.
         */
        storeTablePreset: function (selectedNode) {
            sessionStorage.removeItem('preset-class');

            var table = selectedNode.parentNode.closest('table');
            var tableClass = this.findPresetClass(table.classList, PRESET_REGEX)

            if (!tableClass) tableClass = 'reset-preset'

            sessionStorage.setItem('preset-class', tableClass);
        },

        /**
         * Function that resets table preset after modifying preset and shows popup.
         * @param {HTMLElement} table - table node.
         */
        resetTablePreset: function (table) {
            tinymce.activeEditor.windowManager.alert(self.validationSanitization.dictionary.removePresetMessage, function () {
                table.classList.remove('table-preset-' + table.getAttribute('table-preset-id'));
                table.removeAttribute('table-preset-id');
            });
        },

        /**
         * Function that sets default table preset.
         * @param {HTMLElement} table - table node.
         */
        setDefaultTablePreset: function (table) {
            var defaultPreset = {
                width: '500px',
                borderWidth: '1',
                hasCaption: false,
            }

            com.kms.web.editor.presets.applyTablePreset(defaultPreset, table);
        },

        /**
         * Function that creates a new object of modified preset and clean all empty properties.
         * @param {object} table - object of table from event.
         * @returns {object} cleaned modified preset.
         */
        getModifiedPreset: function (table) {
            var modifiedPreset = {
                alignment: table.style.float,
                backgroundColor: table.style.backgroundColor,
                borderColor: table.style.borderColor,
                borderWidth: table.attributes.border ? table.attributes.border.value : '',
                borderStyle: table.style.borderStyle,
                cellPadding: table.attributes.cellPadding ? table.attributes.cellPadding.value : '',
                cellSpacing: table.attributes.cellSpacing ? table.attributes.cellSpacing.value : '',
                hasCaption: Boolean(table.querySelector('caption')),
                height: table.style.height,
                width: table.style.width
            };

            return _.pick(modifiedPreset, v => v !== '');;
        },

        /**
         * Function that finds linked preset and coverts color properties to rgb.
         * @param {object} table - object of table from event.
         * @param {array} presets - table presets.
         * @returns {object} linked preset.
         */
        getLinkedPreset: function (table, presets) {
            var tablePresetId = this.setTablePresetAttr(table);

            if (tablePresetId) {
                var linkedPreset = presets.find(preset => preset.id === tablePresetId).preset

                if (linkedPreset) {
                    // convertation from HEX to RGB
                    var tempTable = document.createElement('table');

                    tempTable.style.backgroundColor = linkedPreset.backgroundColor;
                    tempTable.style.borderColor = linkedPreset.borderColor;

                    if (linkedPreset.backgroundColor) linkedPreset.backgroundColor = tempTable.style.backgroundColor;
                    if (linkedPreset.borderColor) linkedPreset.borderColor = tempTable.style.borderColor;

                    return linkedPreset;
                }
            }
        },

        /**
         * Function that contains logic of defining preset to apply or reset after table was modified.
         * @param {object} table - object of table from event.
         * @param {array} presets - table presets.
         */
        setupTablePresets: function(table, presets) {
            var isTheSameClass = sessionStorage.getItem('preset-class') === table.className;
            var isResetClass = table.className === 'reset-preset';

            var modifiedPreset = this.getModifiedPreset(table)
            var linkedPreset = this.getLinkedPreset(table, presets)

            var isSameStyles = _.isEqual(linkedPreset, modifiedPreset);

            if (isTheSameClass && !isSameStyles && !isResetClass) {
                this.resetTablePreset(table);
            } else if (!isTheSameClass && isResetClass) {
                this.setDefaultTablePreset(table);
            } else {
                this.updateTablePreset(table, presets);
            }

            table.classList.remove('reset-preset');
        },

        getContentFromHtmlString: function(htmlString) {
            var tempElement = document.createElement('div');
            var sanitizedHtmlString = $.kmsSanitizeContent(htmlString, true);
            tempElement.innerHTML = sanitizedHtmlString;
            return tempElement.innerText || tempElement.textContent;
        },

        setAiGeneratedScenarioSuggestionMessage: function(editor, isAiGenerated, editorName) {
            var $container = $(editor.editorContainer).parent();
            var $aiGeneratedScenarioSuggestionMessage = $container.find('.generate-suggestion-mark');
            var name = editorName || $container.parent().attr('data-element-name');
            var $aiGeneratedScenarioSuggestionHiddenInput = $container.find(':input[name="' + name + '_GENERATED"]');

            if ($aiGeneratedScenarioSuggestionMessage.length && $aiGeneratedScenarioSuggestionHiddenInput.length) {
                $aiGeneratedScenarioSuggestionMessage.toggle(isAiGenerated);
                $aiGeneratedScenarioSuggestionHiddenInput.prop('checked', isAiGenerated);
            }
        },

        handleEditorDrop: async function (e, editorInstance, itemOptions) {
            e.preventDefault();
            e.stopPropagation();

            const items = e.dataTransfer?.items;
            if (!items) return;

            for (const item of items) {
                if (
                    item.kind === 'file' &&
                    item.type.startsWith('image/') &&
                    itemOptions.context
                ) {
                    const file = item.getAsFile();
                    if (file) {
                        await processFileEntry(
                            file,
                            itemOptions.context,
                            this.options.controllerLocation,
                            editorInstance
                        );
                    }
                }
            }
        },
    }
};
