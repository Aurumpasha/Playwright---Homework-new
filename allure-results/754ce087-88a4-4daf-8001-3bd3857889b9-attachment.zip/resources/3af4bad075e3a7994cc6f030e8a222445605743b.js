com.kms.web.component.selectFolderDialog = (function($, self) {
    return self = com.kms.web.component.Boilerplate({
        cmTree : com.kms.web.component.cmTree,
        restrictions : null,
        defaultFolderSubtypes : ["LINKS_FOLDER", "IMAGES", "LIST", "FOLDERTAB", "SPREAD", "TOPICS", "3G_HANDSET"],
        getDefaultButtons : function() {
            return [{
                id : 'select-folder-button',
                disabled : true,
                text : self.dictionary.select
            }];
        },

        getContainer : function(id) {
            var $dialog = $('#' + id);

            if(!$dialog[0]) {
                $dialog = $('<div>').attr('id', id).appendTo('body');
            }

            return $dialog;
        },

        getButtons : function(dialogId, buttons, dfd) {
            return buttons.map(function(btn, idx) {
                var buttonId = typeof btn.id !== 'undefined' ? btn.id : 'button-' + idx;

                return $.extend({}, btn, {
                    id : buttonId,
                    click : function() {
                        var activeNode = $(this).data('tree').dynatree('getActiveNode');

                        dfd.resolve({
                            buttonId : buttonId,
                            node : activeNode,
                            folderId : activeNode && activeNode.data.id
                        });

                        $(this).dialog('close');
                    }
                });
            })
        },

        getPermissions : function(options) {
            // set dtd permissions
            var permissions = {};

            function isFolder(subType) {
                return options.folderSubtypes.indexOf(subType) !== -1;
            }

            function getSubType(data) {
                return data.sub_type;
            }

            function restrictionsBySubtype(res, subType) {
                res[subType] = self.cmTree.dtdsMap[subType].map(getSubType);
                return res;
            }

            permissions = Object.keys(self.cmTree.dtdsMap).filter(isFolder).reduce(restrictionsBySubtype, {});

            if(permissions.FOLDERTAB) {
                // Clone restrictions of FOLDERTAB to other types of folders
                options.folderSubtypes.forEach(function(subType) {
                    permissions[subType] = permissions[subType] || permissions.FOLDERTAB;
                });
            }

            return permissions;
        },

        loadTree : function($dialog, options) {
            self.cmTree.dtdsMapPromise.done(function() {
                // set dtd restrictions
                self.permissions = self.permissions || self.getPermissions(options);

                // initialize tree
                var tree = $('<div>').attr('id', 'relocate-tree').appendTo($dialog).dynatree($.extend({
                    debugLevel : 0,
                    autoCollapse : true,
                    selectMode : 1,
                    imagePath : self.options.imgLocation.concat('/activeicons/'),
                    strings : {
                        loading : self.cmTree.dictionary.loading,
                        loadError : self.cmTree.dictionary.loadError
                    },
                    initAjax : {
                        url : self.options.controllerLocation.concat('/tree/content-management/branch/nodes'),
                        data : {
                            parentId : self.cmTree.options.rootItemId
                        }
                    },

                    onPostInit : function() {
                        $dialog.kmsLoadingArea('hide');
                    },

                    onCreate : function(node) {
                        if(!node.data.hasOwnProperty('id')) {
                            return;
                        }

                        var permissions = self.permissions[node.data.sub_type];
                        var restricted = !self.cmTree.dtdsMapReady || (permissions && !~$.inArray(options.subType, permissions));
                        var isParentNode = options.parentId ? options.parentId == node.data.id : false;

                        $.extend(node.data, {
                            isFolder : true,
                            isLazy : !!parseInt(node.data.sons, 10),
                            restricted : restricted || isParentNode,
                            icon : restricted ? 'restricted.png' : (isParentNode ? 'check.png' : node.data.sub_type.concat('ItemIcon.png'))
                        });

                        node.render();
                    },

                    onLazyRead : function(node) {
                        node.appendAjax($.extend(true, {}, this.options.initAjax, {
                            data : {
                                parentId : node.data.id
                            }
                        }));
                    },

                    onActivate : function(node) {
                        if(!node.data.restricted) {
                            $dialog.dialog('widget').find('#select-folder-button').button('enable');
                        }
                    },

                    onDeactivate : function() {
                        $dialog.dialog('widget').find('#select-folder-button').button('disable');
                    }
                }, options.dynatree || {}));

                // store tree instance
                $dialog.data('tree', tree);
            });
        },

        /**
         * Open select folder dialog
         *
         * Example:
         *
         * var options = {
         *      title: 'Custom Title',
         *      dialogId: 'select-folder-dialog',
         *      folderSubtypes: ['FOLDERTAB', 'TOPICS'],
         *      parentId: '0', // - id of selected folder
         *      subType: 'GENERAL', // - current item subtype that used to check restrictions
         *      buttons: [
         *          {id: 'button-ok', text: 'Ok'},
         *          {id: 'button-cancel', text: 'Cancel'}
         *          {
         *              id: 'button-some',
         *              text: 'do some thing different',
         *              click: function() {
         *                  var $dialog = $(this);
         *                  var activeNode = $dialog.data('tree').dynatree('getActiveNode');
         *              }
         *          }
         *      ], // custom buttons. Default click handler resolve promise returned by the dialog. It can be replaced by custom handler.
         *      dynatree: {} // - dynatree options
         * }
         *
         * com.kms.web.component.selectFolderDialog
         *      .open(options)
         *      .then(callback);
         *
         * function callback(result) {
         *      result.buttonId; // - clicked button id
         *      result.folderId; // - selected folder id
         *      result.node; // - dynatree node of selected folder
         * }
         *
         * @param options
         * @return Promise
         */
        open : function(options) {
            // default options
            options = $.extend({
                title : self.dictionary.selectFolder,
                dialogId : 'select-folder-dialog',
                folderSubtypes : self.defaultFolderSubtypes,
                parentId : null,
                subType : null,
                buttons : self.getDefaultButtons()
            }, options);

            var dfd = $.Deferred();
            var buttons = self.getButtons(options.dialogId, options.buttons, dfd);
            var $dialog = self.getContainer(options.dialogId);

            $dialog.dialog({
                title : options.title,
                autoOpen : false,
                width : 500,
                height : 500,
                resizable : false,
                modal : true,
                open : function() {
                    $dialog.kmsLoadingArea('show');
                    self.loadTree($dialog, options);
                },

                close : function() {
                    $(this).empty();
                },

                buttons : buttons
            });

            $dialog.dialog('open');

            return dfd.promise();
        }
    });
})(jQuery);